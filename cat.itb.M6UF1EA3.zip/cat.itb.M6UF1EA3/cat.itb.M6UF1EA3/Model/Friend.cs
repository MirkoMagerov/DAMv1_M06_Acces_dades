﻿namespace cat.itb.M6UF1EA3.Model
{
    public class Friend
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public Friend(int id, string name)
        {
            Id = id;
            Name = name;
        }
    }
}
