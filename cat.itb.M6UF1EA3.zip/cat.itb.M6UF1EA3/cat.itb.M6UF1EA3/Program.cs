﻿using cat.itb.M6UF1EA3.Cruds;

namespace cat.itb.M6UF1EA3
{
    public class Program
    {
        public static void Main()
        {
            PeopleCRUDS peopleCrud = new PeopleCRUDS();

            //peopleCrud.EX1();
            //peopleCrud.EX2();
            //peopleCrud.EX3();
            //peopleCrud.EX4();
            //peopleCrud.EX5();
            //peopleCrud.EX6();
            //peopleCrud.EX7();
            //peopleCrud.EX8();
        }
    }
}